mysql_credentials = {
    'host': 'localhost',
    'user': 'root',
    'password' : '++P@$$w0rd++',
    'database' : 'car_damage_detection'
}